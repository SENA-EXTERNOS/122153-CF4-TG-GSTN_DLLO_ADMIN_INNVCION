function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5xjzwNv8H42":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

